﻿using CepdiReto.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CepdiReto.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FormasfarmaceuticasController : ControllerBase
    {
        private readonly FormasfarmaceuticasContext _context;

        public FormasfarmaceuticasController(FormasfarmaceuticasContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("crearFormafarmaceuticas")]
        public async Task<IActionResult> CreateFormafarmaceuticas(Formasfarmaceuticas Formafarmaceutica)
        {
            //guarda el Formasfarmaceutica en la base de datos
            await _context.Formasfarmaceuticas.AddAsync(Formafarmaceutica);
            await _context.SaveChangesAsync();

            //devuelve un mensaje de exito
            return Ok();
        }
        [HttpGet]
        [Route("listaFormafarmaceuticas")]
        public async Task<ActionResult<IEnumerable<Formasfarmaceuticas>>> GetFormafarmaceuticas()
        {
            //Obten la lista de Formafarmaceuticas de la base de datos
            var formafarmaceuticas = await _context.Formasfarmaceuticas.ToListAsync();

            //devuelve una lista de Formafarmaceuticas
            return Ok(formafarmaceuticas);
        }

        [HttpGet]
        [Route("verFormafarmaceuticas")]
        public async Task<IActionResult> GetFormafarmaceuticas(int id)
        {
            //obtener el Formafarmaceuticas de la base de datos
            Formasfarmaceuticas Formafarmaceutica = await _context.Formasfarmaceuticas.FindAsync(id);

            //devolver el Formafarmaceuticas
            if (Formafarmaceutica == null)
            {
                return NotFound();
            }

            return Ok(Formafarmaceutica);
        }
        [HttpPut]
        [Route("editarFormafarmaceuticas")]
        public async Task<IActionResult> UpdateFormafarmaceuticas(int id, Formasfarmaceuticas formafermaceutica)
        {
            //Actualizar el Formafarmaceuticas en la base de datos
            var formaExistente = await _context.Formasfarmaceuticas.FindAsync(id);
            formaExistente!.Nombre = formafermaceutica.Nombre;
            formaExistente.Habilitado = formafermaceutica.Habilitado;

            await _context.SaveChangesAsync();

            //devolver un mensaje de exito
            return Ok();
        }

        [HttpDelete]
        [Route("eliminarFormafarmaceuticas")]
        public async Task<IActionResult> DeletFormafarmaceuticas(int id)
        {
            //Eliminar Formafarmaceuticas de la base de datos
            var formaBorrada = await _context.Formasfarmaceuticas.FindAsync(id);
            _context.Formasfarmaceuticas.Remove(formaBorrada!);

            await _context.SaveChangesAsync();

            //Devolver un mensaje de exito
            return Ok();
        }

    }
}
