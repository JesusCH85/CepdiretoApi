﻿using CepdiReto.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CepdiReto.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        private readonly UsuariosContext _context;

        public UsuariosController(UsuariosContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("crearUsuario")]
        public async Task<IActionResult> CreateUsuario(Usuarios Usuario)
        {
            //guarda el Usuario en la base de datos
            await _context.Usuarios.AddAsync(Usuario);
            await _context.SaveChangesAsync();

            //devuelve un mensaje de exito
            return Ok();
        }

        [HttpGet]
        [Route("listaUsuarios")]
        public async Task<ActionResult<IEnumerable<Usuarios>>> GetUsuarios()
        {
            //Obten la lista de Usuarios de la base de datos
            var usuarios = await _context.Usuarios.ToListAsync();

            //devuelve una lista de Usuarios
            return Ok(usuarios);
        }

        [HttpGet]
        [Route("verUsuario")]
        public async Task<IActionResult> GetUsuario(int id)
        {
            //obtener el Usuario de la base de datos
            Usuarios usuario = await _context.Usuarios.FindAsync(id);

            //devolver el Usuario
            if (usuario == null)
            {
                return NotFound();
            }

            return Ok(usuario);
        }

        [HttpPut]
        [Route("editarUsuario")]
        public async Task<IActionResult> UpdateUsuario(int id, Usuarios usuario)
        {
            //Actualizar el Usuario en la base de datos
            var usuarioExistente = await _context.Usuarios.FindAsync(id);
            usuarioExistente!.Nombre = usuario.Nombre;
            usuarioExistente.Usuario = usuario.Usuario;
            usuarioExistente.Password = usuario.Password;
            usuarioExistente.estatus = usuario.estatus;
            usuarioExistente.idPerfil = usuario.idPerfil;

            await _context.SaveChangesAsync();

            //devolver un mensaje de exito
            return Ok();
        }

        [HttpDelete]
        [Route("eliminarUsuario")]
        public async Task<IActionResult> DeleteUsuario(int id)
        {
            //Eliminar Usuario de la base de datos
            var usuarioBorrado = await _context.Usuarios.FindAsync(id);
            _context.Usuarios.Remove(usuarioBorrado!);

            await _context.SaveChangesAsync();

            //Devolver un mensaje de exito
            return Ok();
        }
    }
}
