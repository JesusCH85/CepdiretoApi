﻿using Microsoft.AspNetCore.Mvc;
using CepdiReto.Models;
using Microsoft.EntityFrameworkCore;

namespace CepdiReto.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MedicamentosController : ControllerBase
    {
        private readonly MedicamentosContext _context;

        public MedicamentosController(MedicamentosContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("crearMedicamento")]
        public async Task<IActionResult> CreateMedicamento(Medicamentos Medicamento)
        {
            //guarda el medicamento en la base de datos
            await _context.Medicamentos.AddAsync(Medicamento);
            await _context.SaveChangesAsync();

            //devuelve un mensaje de exito
            return Ok();
        }

        [HttpGet]
        [Route("listaMedicamentos")]
        public async Task<ActionResult<IEnumerable<Medicamentos>>> GetMedicamentos()
        {
            //Obten la lista de medicamentos de la base de datos
            var medicamentos = await _context.Medicamentos.ToListAsync();

            //devuelve una lista de medicamentos
            return Ok(medicamentos);
        }

        [HttpGet]
        [Route("verMedicamento")]
        public async Task<IActionResult> GetMedicamento(int id)
        {
            //obtener el medicamento de la base de datos
            Medicamentos medicamento = await _context.Medicamentos.FindAsync(id);

            //devolver el Medicamento
            if (medicamento == null)
            {
                return NotFound();
            }

            return Ok(medicamento);
        }

        [HttpPut]
        [Route("editarMedicamento")]
        public async Task<IActionResult> UpdateMedicamento(int id, Medicamentos medicamento)
        {
            //Actualizar el Medicamento en la base de datos
            var medicamentoExistente = await _context.Medicamentos.FindAsync(id);
            medicamentoExistente!.Nombre = medicamento.Nombre;
            medicamentoExistente.Concentracion = medicamento.Concentracion;
            medicamentoExistente.idformafarmaceutica = medicamento.idformafarmaceutica;
            medicamentoExistente.Precio = medicamento.Precio;
            medicamentoExistente.stock = medicamento.stock;
            medicamentoExistente.Presentacion = medicamento.Presentacion;
            medicamentoExistente.Bhabilitado = medicamento.Bhabilitado;
            await _context.SaveChangesAsync();

            //devolver un mensaje de exito
            return Ok();
        }

        [HttpDelete]
        [Route("eliminarMedicamento")]
        public async Task<IActionResult> DeleteMedicamento(int id)
        {
            //Eliminar Medicamento de la base de datos
            var medicamentoBorrado = await _context.Medicamentos.FindAsync(id);
            _context.Medicamentos.Remove(medicamentoBorrado!);

            await _context.SaveChangesAsync();

            //Devolver un mensaje de exito
            return Ok();
        }

    }
}
