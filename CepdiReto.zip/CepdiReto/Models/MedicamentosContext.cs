﻿using Microsoft.EntityFrameworkCore;

namespace CepdiReto.Models
{
    public class MedicamentosContext:DbContext
    {
        public MedicamentosContext(DbContextOptions<MedicamentosContext> options) :base(options) 
        { 
        }

        public DbSet<Medicamentos> Medicamentos { get; set; }

    }
}
