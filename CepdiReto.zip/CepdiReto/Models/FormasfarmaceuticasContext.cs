﻿using Microsoft.EntityFrameworkCore;

namespace CepdiReto.Models
{
    public class FormasfarmaceuticasContext:DbContext
    {
        public FormasfarmaceuticasContext(DbContextOptions<FormasfarmaceuticasContext> options) : base(options)
        {
        }

        public DbSet <Formasfarmaceuticas> Formasfarmaceuticas { get; set; }

    }
}
